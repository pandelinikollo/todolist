import { useState } from 'react'
import './App.css'
import TodoList from './components/todolist'

function App() {

  return (
    <>
      <TodoList/>
    </>
  )
}

export default App
